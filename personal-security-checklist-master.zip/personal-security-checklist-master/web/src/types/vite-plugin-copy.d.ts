declare module 'vite-plugin-copy';
