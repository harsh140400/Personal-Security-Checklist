declare module 'progressbar.js';
