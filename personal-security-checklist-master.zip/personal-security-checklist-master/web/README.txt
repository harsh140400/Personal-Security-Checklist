
This is the source for the https://digital-defense.io website, which displays the checklist data interactively

For build, development and deploy instructions, see the main README

If you wish to make content changes, the only file you need to edit is `personal-security-checklist.yml`, in the repo's root

All code here is licensed under MIT


